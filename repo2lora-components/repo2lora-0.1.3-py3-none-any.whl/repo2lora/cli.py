from __future__ import annotations

import argparse

from . import events
from . import __version__, pipeline
from . import settings
from .schema import TASKS


def _common(p: argparse.ArgumentParser) -> None:
    p.add_argument("--repo", default=".", help="path to the git repo (default: .)")
    p.add_argument("--out", help="output dir (default: <repo>/.repo2lora)")


def _mine_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--tasks", nargs="+", choices=TASKS, help="task types to mine (default: all)")
    p.add_argument("--since", help="only history after this date/ISO timestamp")
    p.add_argument("--max-commits", type=int)
    p.add_argument("--max-changed-lines", type=int, default=80, help="skip hunks changing more lines than this")
    p.add_argument("--incremental", action="store_true", help="resume from last mined commit / review timestamp")
    p.add_argument("--github", metavar="OWNER/REPO", help="override GitHub slug (default: from origin remote)")
    p.add_argument("--github-token", help="GitHub token from client app (overrides env)")
    p.add_argument("--github-api", help="GitHub API base URL (overrides env)")
    p.add_argument("--no-github", action="store_true", help="skip PR review mining")
    p.add_argument("--max-reviews", type=int)


def _build_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--min-quality", type=int, default=3)
    p.add_argument("--max-chars", type=int, default=16000, help="prompt+completion char cap (~4 chars/token)")
    p.add_argument("--tokenizer", help="HF tokenizer id for exact token counts, e.g. meta-models/Muse-Glimmer-30B")
    p.add_argument("--max-tokens", type=int, default=4096, help="with --tokenizer; match training sequence_len")
    p.add_argument("--max-per-task", type=int, default=2000)
    p.add_argument("--dedup-distance", type=int, default=3, help="simhash Hamming threshold (0 = exact only)")
    p.add_argument("--val-frac", type=float, default=0.1)
    p.add_argument("--test-frac", type=float, default=0.0)
    p.add_argument("--format", choices=("chat", "prompt-completion"), default="chat")
    p.add_argument("--seed", type=int, default=42)


def _synth_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--tasks", nargs="+", choices=("bug_fix", "refactor", "feature_impl", "code_review"),
                   help="task types to enrich with request/reasoning")
    p.add_argument("--model", help="Meta model id for synthesis")
    p.add_argument("--effort", choices=("minimal", "low", "medium", "high", "xhigh"),
                   help="reasoning effort")
    p.add_argument("--base-url", help="Meta API base URL")
    p.add_argument("--meta-api-key", help="Meta API key from client app (overrides env)")
    p.add_argument("--limit", type=int, help="max examples to synthesize")
    p.add_argument("--concurrency", type=int, help="parallel requests to Meta API")
    p.add_argument("--max-tokens", type=int, help="max completion tokens for synthesis")
    p.add_argument("--min-quality", type=int, help="minimum quality before synthesis")
    p.add_argument("--max-chars", type=int, help="prompt+completion char cap before synthesis")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--allow-contributor", action="store_true")
    p.add_argument("--yes", action="store_true", help="confirm sending code to the model API")


def main(argv=None) -> int:
    settings.load_dotenv(".")
    p = argparse.ArgumentParser(prog="repo2lora", description="Build a LoRA fine-tuning dataset from a git repo.")
    p.add_argument("--version", action="version", version=__version__)
    p.add_argument("--json", action="store_true", help="emit NDJSON progress events on stdout")
    sub = p.add_subparsers(dest="cmd", required=True)

    m = sub.add_parser("mine", help="extract raw examples from git history, PR reviews and docstrings")
    _common(m)
    _mine_args(m)
    m.add_argument("--max-chars", type=int, default=16000)
    m.set_defaults(func=pipeline.mine)

    b = sub.add_parser("build", help="filter, dedup, balance, split and export raw examples")
    _common(b)
    _build_args(b)
    b.set_defaults(func=pipeline.build)

    r = sub.add_parser("run", help="mine + build")
    _common(r)
    _mine_args(r)
    _build_args(r)
    r.set_defaults(func=lambda a: pipeline.mine(a) or pipeline.build(a))

    s = sub.add_parser("sample", help="write a random sample to review.md for human review")
    _common(s)
    s.add_argument("-n", type=int, default=100)
    s.add_argument("--seed", type=int, default=42)
    s.set_defaults(func=pipeline.sample)

    y = sub.add_parser("synthesize", help="use Meta Model API to add request+reasoning for gap cases")
    _common(y)
    _synth_args(y)
    y.set_defaults(func=pipeline.synthesize)

    d = sub.add_parser("doctor", help="check repo2lora prerequisites")
    _common(d)
    d.add_argument("--online", action="store_true", help="also call /models on Meta API")
    d.add_argument("--base-url", help="Meta API base URL override for online check")
    d.add_argument("--meta-api-key", help="Meta API key override for checks")
    d.add_argument("--github-token", help="GitHub token override for checks")
    d.set_defaults(func=pipeline.doctor)

    a = p.parse_args(argv)
    settings.load_dotenv(a.repo)
    events.enable(a.json)
    if a.json:
        events.emit("start", command=a.cmd)
    return a.func(a)


if __name__ == "__main__":
    raise SystemExit(main())
