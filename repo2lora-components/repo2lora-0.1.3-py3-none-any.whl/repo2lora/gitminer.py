from __future__ import annotations

import re
import os
import subprocess
from pathlib import Path
from typing import Iterator, NamedTuple, Optional

from .schema import SYSTEM, Example, render_prompt

CODE_EXTS = {
    ".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".go", ".rs", ".rb", ".php",
    ".cs", ".cpp", ".cc", ".c", ".h", ".hpp", ".kt", ".swift", ".scala",
    ".mjs", ".cjs", ".mts", ".cts",
}
SKIP_PATH_PARTS = (
    "node_modules/", "vendor/", "dist/", "build/", ".min.", "package-lock",
    "yarn.lock", "poetry.lock", "/generated/", "__snapshots__", "_pb2", ".pb.go",
    ".d.ts", ".next/", "coverage/", "storybook-static/", ".stories.", "__mocks__/",
    "pnpm-lock", ".generated.", ".bundle.", ".chunk.",
)
TEST_PATH_RE = re.compile(
    r"(^|/)(tests?|__tests__|specs?|e2e|cypress)/|(^|/)test_[^/]*$|_test\.|\.test\.|\.spec\.|\.e2e\.|\.cy\.|Test\.\w+$"
)
FIX_RE = re.compile(r"\b(fix(es|ed)?|bugs?|hotfix|patch(es|ed)?|resolve[sd]?|regression)\b", re.I)
REFACTOR_RE = re.compile(r"\b(refactor\w*|clean ?up|simplif\w*|restructur\w*|extract\w*|dedup\w*)\b", re.I)
FEATURE_RE = re.compile(r"^(feat(\(.*?\))?:?\s|add\b|implement\w*|support\b|introduce\w*)", re.I)
SKIP_MSG_RE = re.compile(r"\b(revert|merge|bump|dependabot|chore\(deps\)|release|changelog)\b", re.I)
BOT_RE = re.compile(r"\[bot\]|dependabot|renovate|github-actions", re.I)

INSTRUCTIONS = {
    "bug_fix": "Fix the bug described below. Return the corrected code.",
    "refactor": "Refactor the following code as described. Return the updated code.",
    "feature_impl": "Implement the change described below. Return the updated code.",
}

HUNK_RE = re.compile(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")
MAX_EXAMPLES_PER_COMMIT = 10


class Commit(NamedTuple):
    sha: str
    author: str
    date: str
    subject: str
    body: str


def git(repo: Path, *args: str, check: bool = True) -> str:
    p = subprocess.run(
        ["git", "-C", str(repo), *args],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    if check and p.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed: {p.stderr.strip()}")
    return p.stdout if p.returncode == 0 else ""


def is_code(path: str) -> bool:
    return Path(path).suffix in CODE_EXTS and not any(s in path for s in SKIP_PATH_PARTS)


def is_test(path: str) -> bool:
    return bool(TEST_PATH_RE.search(path))


def _stem(path: str) -> str:
    name = Path(path).stem.lower()
    prev = None
    while prev != name:
        prev = name
        name = re.sub(r"(^test_|_test$|\.test$|\.spec$|_spec$|tests?$|spec$)", "", name)
    return name


def head_sha(repo: Path) -> str:
    return git(repo, "rev-parse", "HEAD").strip()


def list_commits(
    repo: Path, since: Optional[str] = None, after: Optional[str] = None, max_commits: Optional[int] = None
) -> Iterator[Commit]:
    args = ["log", "--no-merges", "--format=%H%x1f%an%x1f%aI%x1f%s%x1f%b%x1e"]
    if since:
        args.append(f"--since={since}")
    if max_commits:
        args.append(f"--max-count={max_commits}")
    if after and git(repo, "cat-file", "-t", f"{after}^{{commit}}", check=False).strip() == "commit":
        args.append(f"{after}..HEAD")
    for rec in git(repo, *args).split("\x1e"):
        rec = rec.strip("\n")
        if not rec:
            continue
        sha, author, date, subject, body = (rec.split("\x1f") + [""] * 5)[:5]
        if BOT_RE.search(author):
            continue
        yield Commit(sha.strip(), author, date, subject.strip(), body.strip())


def changed_files(repo: Path, sha: str) -> list[tuple[str, str]]:
    out = git(repo, "show", "--no-renames", "--name-status", "--format=", sha, check=False)
    files = []
    for line in out.splitlines():
        parts = line.split("\t", 1)
        if len(parts) == 2:
            files.append((parts[0][:1], parts[1]))
    return files


def parse_hunks(diff: str) -> list[dict]:
    hunks: list[dict] = []
    cur = None
    for line in diff.splitlines():
        m = HUNK_RE.match(line)
        if m:
            cur = {"start": int(m.group(1)), "before": [], "after": [], "changed": 0}
            hunks.append(cur)
            continue
        if cur is None or line.startswith("\\"):
            continue
        tag, text = line[:1], line[1:]
        if tag == " ":
            cur["before"].append(text)
            cur["after"].append(text)
        elif tag == "-":
            cur["before"].append(text)
            cur["changed"] += 1
        elif tag == "+":
            cur["after"].append(text)
            cur["changed"] += 1
    return hunks


def classify(subject: str) -> Optional[str]:
    if SKIP_MSG_RE.search(subject):
        return None
    if FIX_RE.search(subject):
        return "bug_fix"
    if REFACTOR_RE.search(subject):
        return "refactor"
    if FEATURE_RE.search(subject):
        return "feature_impl"
    return None


def _hunk_examples(repo: Path, name: str, c: Commit, intent: str, files: list[tuple[str, str]], max_changed: int):
    for status, path in files:
        if status != "M" or not is_code(path) or is_test(path):
            continue
        diff = git(repo, "diff", "-U10", "--no-color", "--no-renames", f"{c.sha}^", c.sha, "--", path, check=False)
        for h in parse_hunks(diff):
            if h["changed"] == 0 or h["changed"] > max_changed or h["before"] == h["after"]:
                continue
            context = f"File: {path}\nChange description: {c.subject}"
            if c.body:
                context += f"\n{c.body[:500]}"
            lang = Path(path).suffix.lstrip(".")
            yield Example(
                task_type=intent,
                system=SYSTEM.format(repo=name),
                prompt=render_prompt(INSTRUCTIONS[intent], context, f"Code (from line {h['start']})", "\n".join(h["before"]), lang),
                completion="\n".join(h["after"]),
                repo=name,
                source_ref=f"{c.sha}:{path}",
                group=c.sha,
                meta={"sha": c.sha, "subject": c.subject, "has_body": bool(c.body),
                      "changed_lines": h["changed"], "path": path, "date": c.date},
            )


def _test_examples(repo: Path, name: str, c: Commit, files: list[tuple[str, str]], max_chars: int):
    added_tests = [p for s, p in files if s == "A" and is_code(p) and is_test(p)]
    sources = [p for s, p in files if s in "AM" and is_code(p) and not is_test(p)]
    for t in added_tests:
        cands = [s for s in sources if _stem(s) == _stem(t) and _stem(s)]
        if not cands:
            continue
        # index.ts / utils.ts style names repeat across dirs, so take the nearest directory
        s = max(cands, key=lambda p: len(os.path.commonprefix([os.path.dirname(t), os.path.dirname(p)])))
        src = git(repo, "show", f"{c.sha}:{s}", check=False)
        test = git(repo, "show", f"{c.sha}:{t}", check=False)
        if not src or not test or len(src) > max_chars:
            continue
        yield Example(
            task_type="test_generation",
            system=SYSTEM.format(repo=name),
            prompt=render_prompt("Write unit tests for the following code.", f"Source file: {s}\nTest file: {t}",
                                 "Code", src, Path(s).suffix.lstrip(".")),
            completion=test,
            repo=name,
            source_ref=f"{c.sha}:{t}",
            group=c.sha,
            meta={"sha": c.sha, "subject": c.subject, "path": t, "date": c.date},
        )


def mine_commits(
    repo: Path, name: str, tasks: set[str], since: Optional[str] = None, after: Optional[str] = None,
    max_commits: Optional[int] = None, max_changed: int = 80, max_files: int = 30, max_chars: int = 16000,
) -> Iterator[Example]:
    for c in list_commits(repo, since, after, max_commits):
        files = changed_files(repo, c.sha)
        code_files = [f for f in files if is_code(f[1])]
        if not code_files:
            continue
        n = 0
        intent = classify(c.subject)
        if intent in tasks and len(code_files) <= max_files:
            for ex in _hunk_examples(repo, name, c, intent, files, max_changed):
                yield ex
                n += 1
                if n >= MAX_EXAMPLES_PER_COMMIT:
                    break
        if "test_generation" in tasks:
            yield from _test_examples(repo, name, c, files, max_chars)
