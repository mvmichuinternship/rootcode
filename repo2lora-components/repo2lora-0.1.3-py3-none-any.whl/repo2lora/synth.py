from __future__ import annotations

import json
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from . import events
from .filters import has_secret, score, validate
from .metaapi import ApiError, api_key, chat
from .schema import Example
from .settings import (
    max_chars as default_max_chars,
    meta_base_url,
    meta_model,
    min_quality as default_min_quality,
    reasoning_effort,
    synth_concurrency,
    synth_limit,
    synth_max_tokens,
)
from .store import out_dir, read_raw

SYNTH_TASKS = ("bug_fix", "refactor", "feature_impl", "code_review")
REQUEST_TASKS = {"bug_fix", "refactor", "feature_impl"}

DEVELOPER = """You help build training data for a coding assistant. You are shown a task prompt and the \
known-correct final answer. Reply with exactly these tagged sections, in this order, and nothing else.
{request_spec}<thinking>First-person reasoning, 80-250 words, of what an expert privately works out BEFORE \
answering: restate the goal, locate the relevant code, weigh the approach, spot pitfalls, then settle on \
what to do. Plain prose, no headings. Derive the conclusion from the code itself; never mention being shown \
an answer, a diff or a commit. Do not paste the solution; short inline identifiers are fine.</thinking>"""

REQUEST_SPEC = """<request>A realistic 1-3 sentence message a developer might send to ask for this change, \
in their own words: describe the symptom or goal. Do not describe the fix and do not mention commits.</request>
"""

REQ_RE = re.compile(r"<request>(.*?)</request>", re.S)
THINK_RE = re.compile(r"<thinking>(.*?)</thinking>", re.S)
FENCE_RE = re.compile(r"```.*?```", re.S)
META_RE = re.compile(
    r"\b(known|given|provided|final|correct|reference|ground[- ]truth)\s+(answer|solution|diff|patch|commit)\b"
    r"|\bcommit message\b", re.I)


def _log(msg: str) -> None:
    print(msg, file=sys.stderr)


def _fail(msg: str) -> int:
    _log(msg)
    events.emit("error", message=msg)
    return 1


def build_messages(ex: Example, want_request: bool) -> list[dict]:
    dev = DEVELOPER.format(request_spec=REQUEST_SPEC if want_request else "")
    user = f"### Task prompt\n{ex.prompt}\n### Known-correct final answer\n{ex.completion}"
    return [{"role": "developer", "content": dev}, {"role": "user", "content": user}]


def parse(text: str, want_request: bool) -> tuple[str | None, str]:
    t = THINK_RE.search(text)
    if not t:
        raise ValueError("missing <thinking>")
    r = REQ_RE.search(text) if want_request else None
    return (r.group(1).strip() if r else None), t.group(1).strip()


def check_thinking(think: str, completion: str) -> str | None:
    if not 200 <= len(think) <= 3000:
        return "length"
    if META_RE.search(think):
        return "meta_reference"
    if has_secret(think):
        return "secret"
    if any(len(b.strip().splitlines()) > 6 for b in FENCE_RE.findall(think)):
        return "code_dump"
    copied = sum(1 for line in completion.splitlines() if len(line.strip()) >= 40 and line.strip() in think)
    return "copied_answer" if copied >= 2 else None


def _wants_request(ex: Example) -> bool:
    return ex.task_type in REQUEST_TASKS and bool(ex.meta.get("subject"))


def apply_synth(examples: list[Example], path) -> int:
    """Merge synthesized requests/reasoning into raw examples in place; returns how many were touched."""
    if not path.exists():
        return 0
    recs = {}
    with path.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                r = json.loads(line)
                recs[r["id"]] = r
    n = 0
    for ex in examples:
        r = recs.get(ex.id)
        if not r:
            continue
        desc = ex.meta.get("subject")
        if r.get("request") and desc:
            ex.prompt = ex.prompt.replace(f"Change description: {desc}", f"Request: {r['request']}", 1)
            ex.meta["rewritten"] = True
        ex.meta["reasoning"] = r["reasoning"]
        n += 1
    return n


def run(a) -> int:
    out = out_dir(a)
    model = a.model or meta_model()
    effort = a.effort or reasoning_effort()
    base_url = a.base_url or meta_base_url()
    limit = a.limit if a.limit is not None else synth_limit()
    concurrency = a.concurrency if a.concurrency is not None else synth_concurrency()
    max_tokens = a.max_tokens if a.max_tokens is not None else synth_max_tokens()
    min_quality = a.min_quality if a.min_quality is not None else default_min_quality()
    max_chars = a.max_chars if a.max_chars is not None else default_max_chars()

    synth_path = out / "synth.jsonl"
    done = set()
    if synth_path.exists():
        with synth_path.open(encoding="utf-8") as f:
            done = {json.loads(line)["id"] for line in f if line.strip()}

    tasks = set(a.tasks or SYNTH_TASKS)
    pool = [ex for ex in read_raw(out / "raw.jsonl")
            if ex.task_type in tasks and ex.id not in done
            and validate(ex, max_chars) is None and score(ex) >= min_quality]
    pool.sort(key=lambda e: (-score(e), e.id))
    pool = pool[:limit]
    est_tokens = sum(len(e.prompt) + len(e.completion) for e in pool) // 4 + 450 * len(pool)
    _log(f"{len(pool)} examples eligible (~{est_tokens:,} input tokens) via {model}, effort={effort}")
    if a.dry_run or not pool:
        events.emit("done", stage="synthesize", eligible=len(pool), est_input_tokens=est_tokens, dry_run=True)
        return 0

    key = a.meta_api_key or api_key()
    if not key:
        return _fail("MODEL_API_KEY is not set")
    if "contributor" in model and not a.allow_contributor:
        return _fail("Contributor-mode models let Meta train on your code; pass --allow-contributor to proceed")
    if not a.yes:
        if a.json or not sys.stdin.isatty():
            return _fail("this sends repo code to the Meta Model API; pass --yes to confirm")
        if input(f"Send {len(pool)} examples of repo code to {base_url}? [y/N] ").strip().lower() != "y":
            return 1

    def work(ex: Example):
        want = _wants_request(ex)
        try:
            text, usage = chat(build_messages(ex, want), model, key, effort, max_tokens, base_url)
            req, think = parse(text, want)
        except ApiError as e:
            return ex.id, None, f"api: {e}", {}
        except ValueError as e:
            return ex.id, None, f"format: {e}", {}
        bad = check_thinking(think, ex.completion)
        if bad:
            return ex.id, None, f"rejected: {bad}", usage
        if req and not (15 <= len(req) <= 500 and not has_secret(req)):
            req = None
        return ex.id, {"id": ex.id, "request": req, "reasoning": think, "model": model, "ts": int(time.time())}, None, usage

    ok = failed = tok_in = tok_out = 0
    reasons: dict[str, int] = {}
    ex_pool = ThreadPoolExecutor(max_workers=concurrency)
    try:
        with synth_path.open("a", encoding="utf-8") as f:
            futs = [ex_pool.submit(work, ex) for ex in pool]
            for fut in as_completed(futs):
                _id, rec, err, usage = fut.result()
                tok_in += usage.get("prompt_tokens", 0)
                tok_out += usage.get("completion_tokens", 0)
                if rec:
                    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                    f.flush()
                    ok += 1
                else:
                    failed += 1
                    reasons[err] = reasons.get(err, 0) + 1
                events.emit("progress", stage="synthesize", done=ok + failed, total=len(pool), failed=failed)
                if (ok + failed) % 10 == 0:
                    _log(f"  {ok + failed}/{len(pool)} (failed {failed})")
    except KeyboardInterrupt:
        ex_pool.shutdown(wait=False, cancel_futures=True)
        _log("interrupted; finished results are saved, rerun to resume")
        return 130
    ex_pool.shutdown()
    _log(f"synthesized {ok}, failed {failed} {reasons or ''}; tokens in={tok_in:,} out={tok_out:,} -> {synth_path}")
    events.emit("done", stage="synthesize", ok=ok, failed=failed, reasons=reasons,
                tokens_in=tok_in, tokens_out=tok_out, path=str(synth_path))
    return 0
