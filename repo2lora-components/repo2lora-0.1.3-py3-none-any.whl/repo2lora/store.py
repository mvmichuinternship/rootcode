from __future__ import annotations

from pathlib import Path

from .schema import Example


def out_dir(a) -> Path:
    return Path(a.out) if a.out else Path(a.repo).resolve() / ".repo2lora"


def read_raw(path: Path) -> list[Example]:
    if not path.exists():
        return []
    with path.open(encoding="utf-8") as f:
        return [Example.from_json(line) for line in f if line.strip()]
