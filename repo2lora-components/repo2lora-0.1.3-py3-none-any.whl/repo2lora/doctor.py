from __future__ import annotations

import importlib.util
import shutil
import subprocess
import sys
from pathlib import Path

from . import events
from .ghminer import find_token, parse_slug
from .gitminer import git
from .jsdoc import parser_available
from .metaapi import api_key, list_models
from .settings import meta_base_url


def _check(name: str, ok: bool, detail: str, required: bool = False, hint: str = "") -> dict:
    return {"name": name, "ok": ok, "required": required, "detail": detail, "hint": hint}


def gather(
    repo: Path,
    online: bool = False,
    github_token_override: str | None = None,
    meta_api_key_override: str | None = None,
    base_url_override: str | None = None,
) -> list[dict]:
    checks = [_check("python", sys.version_info >= (3, 9), sys.version.split()[0], True, "Python 3.9+ is required")]

    has_git = shutil.which("git") is not None
    ver = subprocess.run(["git", "--version"], capture_output=True, text=True).stdout.strip() if has_git else ""
    checks.append(_check("git", has_git, ver or "not found", True, "install git"))

    inside = has_git and git(repo, "rev-parse", "--is-inside-work-tree", check=False).strip() == "true"
    commits = git(repo, "rev-list", "--count", "HEAD", check=False).strip() if inside else ""
    checks.append(_check("repository", inside and bool(commits), f"{commits} commits" if commits else str(repo),
                         True, "run inside a git repo that has commits"))

    slug = parse_slug(git(repo, "remote", "get-url", "origin", check=False)) if inside else None
    checks.append(_check("github_remote", bool(slug), slug or "no github.com origin", False,
                         "PR review mining needs a github.com origin remote"))
    gh = github_token_override or find_token()
    checks.append(_check("github_token", bool(gh), "found" if gh else "missing", False,
                         "set GITHUB_TOKEN or run `gh auth login` for PR reviews"))
    checks.append(_check("tree_sitter", parser_available(), "installed" if parser_available() else "missing", False,
                         "pip install 'repo2lora[parse]' for precise JS/TS doc mining"))
    has_tf = importlib.util.find_spec("transformers") is not None
    checks.append(_check("transformers", has_tf, "installed" if has_tf else "missing", False,
                         "pip install 'repo2lora[tokens]' for --tokenizer token filtering"))

    key = meta_api_key_override or api_key()
    checks.append(_check("meta_api_key", bool(key), "set" if key else "missing", False,
                         "set MODEL_API_KEY to use `repo2lora synthesize`"))
    if online and key:
        try:
            base_url = base_url_override or meta_base_url()
            models = list_models(key, base_url)
            checks.append(_check("meta_api_online", True, f"{len(models)} models visible at {base_url}"))
        except Exception as e:  # network or auth failure is reported, not raised
            checks.append(_check("meta_api_online", False, str(e), False, "check the key and network"))
    return checks


def run(a) -> int:
    checks = gather(
        Path(a.repo).resolve(),
        a.online,
        a.github_token,
        a.meta_api_key,
        a.base_url,
    )
    ok = all(c["ok"] for c in checks if c["required"])
    for c in checks:
        mark = "ok  " if c["ok"] else ("FAIL" if c["required"] else "warn")
        line = f"[{mark}] {c['name']}: {c['detail']}"
        print(line + (f"  ({c['hint']})" if not c["ok"] and c["hint"] else ""), file=sys.stderr)
    events.emit("doctor", ok=ok, checks=checks)
    return 0 if ok else 1
