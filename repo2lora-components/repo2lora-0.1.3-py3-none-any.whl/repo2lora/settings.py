from __future__ import annotations

import os
from pathlib import Path

DEFAULT_META_BASE_URL = "https://api.meta.ai/v1"
DEFAULT_META_MODEL = "muse-spark-1.3"
DEFAULT_REASONING_EFFORT = "low"
DEFAULT_SYNTH_LIMIT = 2000
DEFAULT_SYNTH_CONCURRENCY = 4
DEFAULT_SYNTH_MAX_TOKENS = 2048
DEFAULT_MIN_QUALITY = 3
DEFAULT_MAX_CHARS = 16000


def load_dotenv(repo: str | Path = ".") -> None:
    path = Path(repo).resolve() / ".env"
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip(), v.strip().strip('"').strip("'")
        if k:
            os.environ.setdefault(k, v)


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


def meta_base_url() -> str:
    return os.environ.get("MODEL_API_BASE_URL", DEFAULT_META_BASE_URL)


def meta_model() -> str:
    return os.environ.get("REPO2LORA_META_MODEL", DEFAULT_META_MODEL)


def reasoning_effort() -> str:
    return os.environ.get("REPO2LORA_REASONING_EFFORT", DEFAULT_REASONING_EFFORT)


def synth_limit() -> int:
    return _int("REPO2LORA_SYNTH_LIMIT", DEFAULT_SYNTH_LIMIT)


def synth_concurrency() -> int:
    return _int("REPO2LORA_SYNTH_CONCURRENCY", DEFAULT_SYNTH_CONCURRENCY)


def synth_max_tokens() -> int:
    return _int("REPO2LORA_SYNTH_MAX_TOKENS", DEFAULT_SYNTH_MAX_TOKENS)


def min_quality() -> int:
    return _int("REPO2LORA_MIN_QUALITY", DEFAULT_MIN_QUALITY)


def max_chars() -> int:
    return _int("REPO2LORA_MAX_CHARS", DEFAULT_MAX_CHARS)