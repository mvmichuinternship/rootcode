from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field

TASKS = (
    "bug_fix",
    "refactor",
    "feature_impl",
    "test_generation",
    "docstring_generation",
    "code_review",
)

SYSTEM = (
    "You are an expert software engineer working in the {repo} codebase. "
    "Follow its conventions and patterns."
)


@dataclass
class Example:
    task_type: str
    system: str
    prompt: str
    completion: str
    repo: str
    source_ref: str
    group: str  # split unit: examples sharing a group never straddle train/val
    quality: int = 0
    meta: dict = field(default_factory=dict)
    id: str = ""

    def __post_init__(self) -> None:
        if not self.id:
            key = f"{self.task_type}\0{self.prompt}\0{self.completion}"
            self.id = hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False)

    @classmethod
    def from_json(cls, line: str) -> "Example":
        return cls(**json.loads(line))


def render_prompt(instruction: str, context: str, code_label: str, code: str, lang: str = "") -> str:
    return (
        f"### Task\n{instruction}\n\n"
        f"### Context\n{context}\n\n"
        f"### {code_label}\n```{lang}\n{code}\n```\n"
    )
