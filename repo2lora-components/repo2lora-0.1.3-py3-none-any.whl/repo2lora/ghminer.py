from __future__ import annotations

import json
import os
import re
import subprocess
import time
import urllib.error
import urllib.request
from typing import Iterator, Optional

from .gitminer import BOT_RE
from .schema import SYSTEM, Example, render_prompt

API = os.environ.get("REPO2LORA_GITHUB_API", "https://api.github.com")
REMOTE_RE = re.compile(r"github\.com[:/]([^/]+/[^/]+?)(?:\.git)?/?$")


def parse_slug(remote_url: str) -> Optional[str]:
    m = REMOTE_RE.search(remote_url.strip())
    return m.group(1) if m else None


def find_token() -> Optional[str]:
    tok = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if tok:
        return tok
    try:
        p = subprocess.run(["gh", "auth", "token"], capture_output=True, text=True, timeout=10)
        return p.stdout.strip() or None if p.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def _get(url: str, token: str):
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "repo2lora",
    }
    for attempt in range(5):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=30) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code not in (403, 429) or attempt == 4:
                raise
            wait = int(e.headers.get("Retry-After") or 0)
            if not wait and e.headers.get("X-RateLimit-Remaining") == "0":
                wait = max(0, int(e.headers.get("X-RateLimit-Reset", 0)) - int(time.time())) + 1
            time.sleep(min(wait or 2 ** attempt, 300))


def mine_reviews(
    slug: str, name: str, token: str, since: Optional[str] = None, max_comments: Optional[int] = None,
    api_base: Optional[str] = None,
) -> Iterator[Example]:
    api_base = (api_base or API).rstrip("/")
    pr_cache: dict[int, dict] = {}
    seen = 0
    page = 1
    while True:
        url = f"{api_base}/repos/{slug}/pulls/comments?per_page=100&page={page}&sort=created&direction=asc"
        if since:
            url += f"&since={since}"
        comments = _get(url, token)
        if not comments:
            return
        for c in comments:
            if c.get("in_reply_to_id") or (c.get("user") or {}).get("type") == "Bot" or BOT_RE.search((c.get("user") or {}).get("login", "")):
                continue
            pr_num = int(c["pull_request_url"].rsplit("/", 1)[1])
            if pr_num not in pr_cache:
                pr_cache[pr_num] = _get(f"{api_base}/repos/{slug}/pulls/{pr_num}", token)
            pr = pr_cache[pr_num]
            context = f"File: {c['path']}\nPR: {pr.get('title', '')}"
            if pr.get("body"):
                context += f"\n{pr['body'][:500]}"
            yield Example(
                task_type="code_review",
                system=SYSTEM.format(repo=name),
                prompt=render_prompt("Review the following code change and write the review comment a senior maintainer would leave.",
                                     context, "Diff", c["diff_hunk"], "diff"),
                completion=c["body"],
                repo=name,
                source_ref=f"{slug}#{pr_num}/{c['id']}",
                group=f"pr-{pr_num}",
                meta={"pr": pr_num, "merged": bool(pr.get("merged_at")), "created_at": c["created_at"], "path": c["path"]},
            )
            seen += 1
            if max_comments and seen >= max_comments:
                return
        if len(comments) < 100:
            return
        page += 1
