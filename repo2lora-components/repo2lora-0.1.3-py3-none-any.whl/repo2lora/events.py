from __future__ import annotations

import json
import sys

_enabled = False


def enable(on: bool) -> None:
    global _enabled
    _enabled = on


def emit(event: str, **fields) -> None:
    """One NDJSON object per line on stdout; human logs stay on stderr."""
    if _enabled:
        sys.stdout.write(json.dumps({"event": event, **fields}, ensure_ascii=False) + "\n")
        sys.stdout.flush()
