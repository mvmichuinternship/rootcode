from __future__ import annotations

import ast
from pathlib import Path
from typing import Iterator

from .gitminer import git, is_code, is_test
from .jsdoc import mine_jsdoc
from .schema import SYSTEM, Example, render_prompt

MAX_FUNC_LINES = 80
MIN_FUNC_LINES = 3


def _strip_docstring(lines: list[str], node: ast.AST) -> str:
    start = min([node.lineno] + [d.lineno for d in node.decorator_list]) - 1
    doc = node.body[0]
    body = lines[start:doc.lineno - 1] + lines[doc.end_lineno:node.end_lineno]
    return "\n".join(body)


def mine_docstrings(repo: Path, name: str) -> Iterator[Example]:
    yield from mine_python_docstrings(repo, name)
    yield from mine_jsdoc(repo, name)


def mine_python_docstrings(repo: Path, name: str) -> Iterator[Example]:
    """Python-only: function bodies without their docstring -> the docstring."""
    for path in git(repo, "ls-files", "*.py").splitlines():
        if not is_code(path) or is_test(path):
            continue
        try:
            source = (repo / path).read_text(encoding="utf-8")
            tree = ast.parse(source)
        except (OSError, SyntaxError, UnicodeDecodeError, ValueError):
            continue
        lines = source.splitlines()
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            doc = ast.get_docstring(node)
            if not doc or not isinstance(node.body[0], ast.Expr) or len(node.body) < 2:
                continue
            n_lines = node.end_lineno - node.lineno + 1
            if not MIN_FUNC_LINES <= n_lines <= MAX_FUNC_LINES:
                continue
            yield Example(
                task_type="docstring_generation",
                system=SYSTEM.format(repo=name),
                prompt=render_prompt("Write the docstring for the following function.", f"File: {path}",
                                     "Code", _strip_docstring(lines, node), "py"),
                completion=doc,
                repo=name,
                source_ref=f"{path}:{node.name}",
                group=path,
                meta={"path": path, "func": node.name},
            )
