from __future__ import annotations

import hashlib
import re
from typing import Sequence

from .schema import Example

TOKEN_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|\"(?:[^\"\\]|\\.)*\"|'(?:[^'\\]|\\.)*'|\S")
KEYWORDS = frozenset(
    "if else elif for while return def class import from as try except finally raise with yield lambda "
    "function const let var new this self async await switch case break continue public private static "
    "void int string bool true false null none fn func struct impl pub use mod package interface extends "
    "implements throw throws catch in is not and or typeof instanceof delete void export default type enum "
    "readonly declare abstract namespace of undefined constructor super get set keyof satisfies".split()
)
SHINGLE = 4


def normalize(text: str) -> list[str]:
    """Rename-insensitive token stream: identifiers, numbers and strings collapse to placeholders."""
    out = []
    for t in TOKEN_RE.findall(text):
        if t[0].isalpha() or t[0] == "_":
            out.append(t if t.lower() in KEYWORDS else "ID")
        elif t[0].isdigit():
            out.append("0")
        elif t[0] in "\"'":
            out.append("S")
        else:
            out.append(t)
    return out


def simhash(text: str) -> int:
    toks = normalize(text)
    shingles = {" ".join(toks[i:i + SHINGLE]) for i in range(max(1, len(toks) - SHINGLE + 1))}
    hashes = [int.from_bytes(hashlib.blake2b(s.encode(), digest_size=8).digest(), "big") for s in shingles]
    if len(hashes) > 256:  # subsample long texts to keep this O(n) in pure Python
        hashes = [h for h in hashes if h % 8 == 0] or hashes
    vec = [0] * 64
    for h in hashes:
        for b in range(64):
            vec[b] += 1 if (h >> b) & 1 else -1
    return sum(1 << b for b in range(64) if vec[b] > 0)


def _bands(h: int, n: int) -> list[tuple[int, int]]:
    width = 64 // n
    return [(i, (h >> (i * width)) & ((1 << width) - 1) if i < n - 1 else h >> (i * width)) for i in range(n)]


def dedup(examples: Sequence[Example], max_distance: int = 3) -> tuple[list[Example], int]:
    """Keep the highest-quality example of each near-duplicate cluster (Hamming <= max_distance)."""
    ordered = sorted(examples, key=lambda e: (-e.quality, e.id))
    buckets: dict[tuple[int, int], list[int]] = {}
    kept: list[Example] = []
    hashes: list[int] = []
    removed = 0
    for ex in ordered:
        h = simhash(ex.prompt + "\n" + ex.completion)
        bands = _bands(h, max_distance + 1)
        dup = any(
            bin(h ^ hashes[j]).count("1") <= max_distance
            for band in bands for j in buckets.get(band, ())
        )
        if dup:
            removed += 1
            continue
        for band in bands:
            buckets.setdefault(band, []).append(len(kept))
        kept.append(ex)
        hashes.append(h)
    return kept, removed
