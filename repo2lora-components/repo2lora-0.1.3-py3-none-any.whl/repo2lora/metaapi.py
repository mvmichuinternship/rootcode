from __future__ import annotations

import json
import os
import random
import time
import urllib.error
import urllib.request
from typing import Optional

from .settings import meta_base_url

DEFAULT_MODEL = "muse-spark-1.3"  # Standard mode: content is not used for Meta training
EFFORTS = ("minimal", "low", "medium", "high", "xhigh")
RETRYABLE = (429, 500, 502, 503, 504)


class ApiError(RuntimeError):
    pass


def api_key() -> Optional[str]:
    return os.environ.get("MODEL_API_KEY")


def _request(method: str, path: str, key: str, body: Optional[dict] = None,
             base_url: Optional[str] = None, timeout: float = 180, retries: int = 6) -> dict:
    base_url = base_url or meta_base_url()
    url = base_url.rstrip("/") + path
    data = json.dumps(body).encode("utf-8") if body is not None else None
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json", "User-Agent": "repo2lora"}
    for attempt in range(retries):
        wait = 0.5 * 2 ** attempt + random.random()
        try:
            req = urllib.request.Request(url, data=data, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code in RETRYABLE and attempt < retries - 1:
                try:
                    wait = max(wait, float(e.headers.get("Retry-After") or 0))
                except ValueError:
                    pass
                time.sleep(wait)
                continue
            raise ApiError(f"HTTP {e.code}: {e.read().decode('utf-8', 'replace')[:300]}")
        except OSError as e:
            if attempt < retries - 1:
                time.sleep(wait)
                continue
            raise ApiError(str(e))
    raise ApiError("retries exhausted")


def chat(messages: list[dict], model: str, key: str, effort: str = "low", max_tokens: int = 4096,
         base_url: Optional[str] = None) -> tuple[str, dict]:
    """Chat Completions call. Sampling params are left at defaults, as Meta recommends for Muse Spark."""
    data = _request("POST", "/chat/completions", key, {
        "model": model,
        "messages": messages,
        "reasoning_effort": effort,
        "max_completion_tokens": max_tokens,  # shared by hidden reasoning and visible output
    }, base_url)
    try:
        choice = data["choices"][0]
        text = choice["message"].get("content") or ""
    except (KeyError, IndexError, TypeError, AttributeError):
        raise ApiError("malformed response")
    if choice.get("finish_reason") == "length":
        raise ApiError("output truncated; raise --max-tokens")
    return text.strip(), data.get("usage") or {}


def list_models(key: str, base_url: Optional[str] = None) -> list[str]:
    base_url = base_url or meta_base_url()
    data = _request("GET", "/models", key, base_url=base_url, timeout=30, retries=2)
    return [m.get("id", "") for m in data.get("data", [])]
