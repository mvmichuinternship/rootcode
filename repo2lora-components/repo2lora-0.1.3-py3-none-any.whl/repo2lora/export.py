from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Sequence

from .schema import Example


def _assistant_text(ex: Example) -> str:
    r = ex.meta.get("reasoning")
    return f"<thinking>{r}</thinking>\n\n{ex.completion}" if r else ex.completion


def to_record(ex: Example, fmt: str) -> dict:
    assistant = _assistant_text(ex)
    if fmt == "chat":
        return {
            "messages": [
                {"role": "system", "content": ex.system},
                {"role": "user", "content": ex.prompt},
                {"role": "assistant", "content": assistant},
            ],
            "id": ex.id,
            "task_type": ex.task_type,
        }
    return {"prompt": f"{ex.system}\n\n{ex.prompt}\n### Response\n", "completion": assistant,
            "id": ex.id, "task_type": ex.task_type}


def write_jsonl(examples: Sequence[Example], path: Path, fmt: str) -> str:
    h = hashlib.sha256()
    with path.open("w", encoding="utf-8") as f:
        for ex in examples:
            line = json.dumps(to_record(ex, fmt), ensure_ascii=False) + "\n"
            f.write(line)
            h.update(line.encode("utf-8"))
    return h.hexdigest()
