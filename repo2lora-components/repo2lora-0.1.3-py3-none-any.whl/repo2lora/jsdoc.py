from __future__ import annotations

import re
import textwrap
from functools import lru_cache
from pathlib import Path
from typing import Iterator, Optional

from .gitminer import git, is_code, is_test
from .schema import SYSTEM, Example, render_prompt

JS_EXTS = (".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".mts", ".cts")
MIN_LINES, MAX_LINES = 3, 80
MAX_FILE_CHARS = 400_000

DOC_RE = re.compile(r"/\*\*(?!/)(.*?)\*/", re.S)
PRAGMA_RE = re.compile(r"@(license|fileoverview|file|jsx|jsxImportSource|flow|ts-check|jest-environment)\b")
NOT_METHODS = {"if", "for", "while", "switch", "catch", "return", "function", "super", "await",
               "import", "new", "typeof", "with", "else", "do"}

DECL_RE = re.compile(
    r"(?:export\s+(?:default\s+)?)?(?:declare\s+)?(?:"
    r"(?:async\s+)?function\b\*?\s*(?P<fn>[\w$]*)"
    r"|(?:abstract\s+)?class\s+(?P<cls>[\w$]+)"
    r"|(?:const|let|var)\s+(?P<var>[\w$]+)\s*(?::[^=;]+)?=(?!=)"
    r"|(?:(?:public|private|protected|static|readonly|override)\s+)*(?P<prop>[#\w$]+)\s*(?::[^=;(){}]+)?=(?!=|>)"
    r"|(?:(?:public|private|protected|static|async|override|abstract|get|set)\s+)*(?P<m>[#\w$]+)\s*(?:<[^>(]*>)?\s*\("
    r")"
)


def _skip(src: str, i: int) -> int:
    """If a comment or string/template literal starts at i, return the index after it, else i."""
    n = len(src)
    c = src[i]
    if c == "/" and src.startswith("//", i):
        j = src.find("\n", i)
        return n if j < 0 else j
    if c == "/" and src.startswith("/*", i):
        j = src.find("*/", i + 2)
        return n if j < 0 else j + 2
    if c in "'\"":  # unterminated quotes (JSX text apostrophes) end at the newline
        j = i + 1
        while j < n and src[j] not in (c, "\n"):
            j += 2 if src[j] == "\\" else 1
        return min(j + 1, n)
    if c == "`":
        j = i + 1
        while j < n and src[j] != "`":
            if src[j] == "\\":
                j += 2
            elif src.startswith("${", j):
                k = _match(src, j + 1)
                j = n if k < 0 else k
            else:
                j += 1
        return min(j + 1, n)
    return i


def _match(src: str, i: int) -> int:
    """src[i] is '{'; return the index after its matching '}', or -1."""
    depth, n = 0, len(src)
    while i < n:
        j = _skip(src, i)
        if j != i:
            i = j
            continue
        c = src[i]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    return -1


def _body_end(src: str, i: int, paren: int) -> Optional[int]:
    """End of a function/class/method body; None for signature-only declarations."""
    n = len(src)
    while i < n:
        j = _skip(src, i)
        if j != i:
            i = j
            continue
        c = src[i]
        if c in "([":
            paren += 1
        elif c in ")]":
            paren -= 1
        elif paren <= 0:
            if c == "{":
                e = _match(src, i)
                return None if e < 0 else e
            if c in ";}":
                return None
        i += 1
    return None


def _expr_end(src: str, i: int) -> int:
    """End of an initializer expression, with or without a trailing semicolon."""
    n, depth, last, last2 = len(src), 0, "", ""
    while i < n:
        j = _skip(src, i)
        if j != i:
            last = last2 = src[j - 1]
            i = j
            continue
        c = src[i]
        if c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
            if depth < 0:
                return i
        elif depth == 0:
            if c == ";":
                return i + 1
            if c == "\n":
                k = i
                while k < n and src[k] in " \t\r\n":
                    k += 1
                nxt = src[k] if k < n else ""
                if not (last2 == "=>" or last in "=(,+-*&|?:" or nxt in (".", "?", ":", "&", "|", "+")) or not nxt:
                    return i
        if not c.isspace():
            last, last2 = c, (last2 + c)[-2:]
        i += 1
    return n


def _skip_decorators(src: str, i: int) -> int:
    n = len(src)
    while i < n and src[i] == "@":
        i += 1
        while i < n and (src[i].isalnum() or src[i] in "_$."):
            i += 1
        if i < n and src[i] == "(":
            depth = 0
            while i < n:
                j = _skip(src, i)
                if j != i:
                    i = j
                    continue
                depth += src[i] == "("
                depth -= src[i] == ")"
                i += 1
                if depth == 0:
                    break
        while i < n and src[i].isspace():
            i += 1
    return i


def _line_start(src: str, i: int) -> int:
    return src.rfind("\n", 0, i) + 1


def _parser(ext: str):
    kind = "tsx" if ext == ".tsx" else "typescript" if ext in (".ts", ".mts", ".cts") else "javascript"
    return _load_parser(kind)


@lru_cache(maxsize=None)
def _load_parser(kind: str):
    try:
        from tree_sitter import Language, Parser
        if kind == "javascript":
            import tree_sitter_javascript as mod
            lang = mod.language()
        else:
            import tree_sitter_typescript as mod
            lang = mod.language_tsx() if kind == "tsx" else mod.language_typescript()
        return Parser(Language(lang))
    except (ImportError, TypeError):
        return None


def parser_available() -> bool:
    return _load_parser("typescript") is not None and _load_parser("javascript") is not None


DECL_NODES = {
    "function_declaration", "generator_function_declaration", "class_declaration", "abstract_class_declaration",
    "method_definition", "lexical_declaration", "variable_declaration", "public_field_definition",
    "field_definition", "interface_declaration", "type_alias_declaration", "enum_declaration",
}


def _decl_name(node) -> str:
    if node.type == "export_statement":
        inner = node.child_by_field_name("declaration") or node.child_by_field_name("value")
        return _decl_name(inner) if inner is not None else "default"
    if node.type in ("lexical_declaration", "variable_declaration"):
        d = next((c for c in node.named_children if c.type == "variable_declarator"), None)
        node = d if d is not None else node
    name = node.child_by_field_name("name")
    return name.text.decode("utf-8", "replace") if name is not None else "default"


def _is_documentable(node) -> bool:
    if node.type == "export_statement":
        inner = node.child_by_field_name("declaration") or node.child_by_field_name("value")
        return inner is not None and inner.type in DECL_NODES | {"arrow_function", "function_expression", "function"}
    return node.type in DECL_NODES


def _parsed_examples(parser, src: str, path: str, name: str) -> Iterator[Example]:
    data = src.encode("utf-8")
    lang = Path(path).suffix.lstrip(".")
    stack = [parser.parse(data).root_node]
    while stack:
        node = stack.pop()
        stack.extend(node.children)
        if node.type != "comment" or not data.startswith(b"/**", node.start_byte):
            continue
        text = data[node.start_byte:node.end_byte].decode("utf-8", "replace")
        ls = data.rfind(b"\n", 0, node.start_byte) + 1
        if data[ls:node.start_byte].strip() or PRAGMA_RE.search(text) or not text.endswith("*/"):
            continue
        if len(re.sub(r"^\s*(/\*\*|\*/|\*)? ?", "", text, flags=re.M).replace("*/", "").strip()) < 25:
            continue
        target = node.next_named_sibling
        while target is not None and target.type == "comment":
            target = target.next_named_sibling
        if target is None or not _is_documentable(target):
            continue
        tls = data.rfind(b"\n", 0, target.start_byte) + 1
        code = textwrap.dedent(data[tls:target.end_byte].decode("utf-8", "replace")).strip("\n")
        if not MIN_LINES <= code.count("\n") + 1 <= MAX_LINES:
            continue
        ident = _decl_name(target)
        yield Example(
            task_type="docstring_generation",
            system=SYSTEM.format(repo=name),
            prompt=render_prompt("Write the JSDoc/TSDoc comment for the following code.", f"File: {path}", "Code", code, lang),
            completion=textwrap.dedent(data[ls:node.end_byte].decode("utf-8", "replace")),
            repo=name,
            source_ref=f"{path}:{ident}",
            group=path,
            meta={"path": path, "func": ident, "parser": "tree-sitter"},
        )


def _file_examples(src: str, path: str, name: str) -> Iterator[Example]:
    parser = _parser(Path(path).suffix)
    if parser is not None:
        yield from _parsed_examples(parser, src, path, name)
    else:
        yield from _scanned_examples(src, path, name)


def _scanned_examples(src: str, path: str, name: str) -> Iterator[Example]:
    lang = Path(path).suffix.lstrip(".")
    for m in DOC_RE.finditer(src):
        ls = _line_start(src, m.start())
        if src[ls:m.start()].strip() or PRAGMA_RE.search(m.group(1)):
            continue
        plain = re.sub(r"^\s*\*? ?", "", m.group(1), flags=re.M).strip()
        if len(plain) < 25:
            continue
        start = m.end()
        while start < len(src) and src[start].isspace():
            start += 1
        pos = _skip_decorators(src, start)
        dm = DECL_RE.match(src, pos)
        if not dm:
            continue
        g = dm.groupdict()
        ident = g["fn"] or g["cls"] or g["var"] or g["prop"] or g["m"] or "default"
        if g["m"] in NOT_METHODS:
            continue
        if g["var"] or g["prop"]:
            end = _expr_end(src, dm.end())
        else:
            end = _body_end(src, dm.end(), 1 if g["m"] else 0)
            if end is None:
                continue
        code = textwrap.dedent(src[_line_start(src, start):end]).strip("\n")
        if not MIN_LINES <= code.count("\n") + 1 <= MAX_LINES:
            continue
        yield Example(
            task_type="docstring_generation",
            system=SYSTEM.format(repo=name),
            prompt=render_prompt("Write the JSDoc/TSDoc comment for the following code.", f"File: {path}", "Code", code, lang),
            completion=textwrap.dedent(src[ls:m.end()]),
            repo=name,
            source_ref=f"{path}:{ident}",
            group=path,
            meta={"path": path, "func": ident},
        )


def mine_jsdoc(repo: Path, name: str) -> Iterator[Example]:
    """JS/TS (incl. JSX/TSX): code without its JSDoc/TSDoc block -> the block."""
    for path in git(repo, "ls-files").splitlines():
        if not path.endswith(JS_EXTS) or not is_code(path) or is_test(path):
            continue
        try:
            src = (repo / path).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if len(src) <= MAX_FILE_CHARS:
            yield from _file_examples(src, path, name)
