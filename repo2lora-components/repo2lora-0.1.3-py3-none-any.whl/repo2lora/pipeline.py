from __future__ import annotations

import hashlib
import json
import os
import random
import sys
from collections import Counter
from pathlib import Path

from . import __version__
from . import events
from .dedup import dedup
from .doctor import run as doctor_run
from .docminer import mine_docstrings
from .export import write_jsonl
from .filters import load_token_counter, score, validate
from .ghminer import find_token, mine_reviews, parse_slug
from .gitminer import git, head_sha, mine_commits
from .jsdoc import parser_available
from .schema import TASKS
from .store import out_dir, read_raw
from .synth import apply_synth, run as synth_run

COMMIT_TASKS = {"bug_fix", "refactor", "feature_impl", "test_generation"}


def _log(msg: str) -> None:
    print(msg, file=sys.stderr)


def _load_state(out: Path) -> dict:
    p = out / "state.json"
    return json.loads(p.read_text()) if p.exists() else {}


def _save_state(out: Path, state: dict) -> None:
    (out / "state.json").write_text(json.dumps(state, indent=2))


def mine(a) -> int:
    repo = Path(a.repo).resolve()
    out = out_dir(a)
    out.mkdir(parents=True, exist_ok=True)
    (out / ".gitignore").write_text("*\n")
    raw_path = out / "raw.jsonl"

    remote = git(repo, "remote", "get-url", "origin", check=False)
    env_slug = parse_slug(os.environ.get("REPO2LORA_GITHUB_REPO", "")) or os.environ.get("REPO2LORA_GITHUB_SLUG")
    slug = a.github or env_slug or parse_slug(remote)
    name = slug.split("/")[-1] if slug else repo.name
    tasks = set(a.tasks or TASKS)
    state = _load_state(out) if a.incremental else {}
    known = {e.id for e in read_raw(raw_path)}
    new: list[Example] = []

    def collect(it, label: str) -> None:
        n = 0
        for ex in it:
            if ex.id not in known:
                known.add(ex.id)
                new.append(ex)
                n += 1
        _log(f"  {label}: +{n}")

    _log(f"Mining {name} ...")
    events.emit("start", stage="mine", repo=str(repo), out=str(out), tasks=sorted(tasks))
    if tasks & COMMIT_TASKS:
        collect(mine_commits(repo, name, tasks, a.since, state.get("last_commit"), a.max_commits,
                             a.max_changed_lines, max_chars=a.max_chars), "commits")
        state["last_commit"] = head_sha(repo)
    if "docstring_generation" in tasks:
        if not parser_available():
            _log("  note: JS/TS docs use the regex scanner; `pip install 'repo2lora[parse]'` for the real parser")
        collect(mine_docstrings(repo, name), "docstrings")
    if "code_review" in tasks and not a.no_github:
        token = a.github_token or find_token()
        if not slug or not token:
            _log("  reviews: skipped (need a github.com remote and GITHUB_TOKEN or `gh auth login`)")
        else:
            since = a.since if not state.get("last_review_ts") else state["last_review_ts"]
            collect(mine_reviews(slug, name, token, since, a.max_reviews, a.github_api), "reviews")
            stamps = [e.meta["created_at"] for e in new if e.task_type == "code_review"]
            if stamps:
                state["last_review_ts"] = max(stamps)

    with raw_path.open("a", encoding="utf-8") as f:
        for ex in new:
            f.write(ex.to_json() + "\n")
    _save_state(out, state)
    _log(f"Raw examples: +{len(new)} (total {len(known)}) -> {raw_path}")
    events.emit("done", stage="mine", added=len(new), total=len(known), path=str(raw_path))
    return 0


def _bucket(group: str, seed: int) -> float:
    return int(hashlib.sha256(f"{seed}:{group}".encode()).hexdigest()[:8], 16) / 0xFFFFFFFF


def split(examples: list[Example], val_frac: float, test_frac: float, seed: int):
    train, val, test = [], [], []
    for ex in examples:
        b = _bucket(ex.group, seed)
        (val if b < val_frac else test if b < val_frac + test_frac else train).append(ex)
    return train, val, test


def cap_per_task(examples: list[Example], cap: int) -> list[Example]:
    by_task: dict[str, list[Example]] = {}
    for ex in sorted(examples, key=lambda e: (-e.quality, e.id)):
        by_task.setdefault(ex.task_type, []).append(ex)
    return [ex for items in by_task.values() for ex in items[:cap]]


def _dist(examples: list[Example]) -> dict:
    return dict(Counter(e.task_type for e in examples).most_common())


def build(a) -> int:
    repo = Path(a.repo).resolve()
    out = out_dir(a)
    raw = read_raw(out / "raw.jsonl")
    if not raw:
        _log("No raw examples. Run `repo2lora mine` first.")
        events.emit("error", stage="build", message="no raw examples")
        return 1

    applied = apply_synth(raw, out / "synth.jsonl")
    if applied:
        _log(f"Applied synthesized request/reasoning to {applied} examples")

    count_tokens = load_token_counter(a.tokenizer) if a.tokenizer else None
    rejected: Counter = Counter()
    kept: list[Example] = []
    for ex in raw:
        reason = validate(ex, a.max_chars)
        if not reason and count_tokens and count_tokens(ex) > a.max_tokens:
            reason = "too_many_tokens"
        if reason:
            rejected[reason] += 1
            continue
        ex.quality = score(ex)
        if ex.quality < a.min_quality:
            rejected["low_quality"] += 1
            continue
        kept.append(ex)

    kept, dups = dedup(kept, a.dedup_distance)
    rejected["near_duplicate"] = dups
    if a.max_per_task:
        kept = cap_per_task(kept, a.max_per_task)
    kept.sort(key=lambda e: e.id)
    random.Random(a.seed).shuffle(kept)

    train, val, test = split(kept, a.val_frac, a.test_frac, a.seed)
    if not val:
        _log("warning: validation split is empty (too few groups); lower --min-quality or mine more history")

    ds = out / "dataset"
    ds.mkdir(parents=True, exist_ok=True)
    hashes = {"train": write_jsonl(train, ds / "train.jsonl", a.format),
              "val": write_jsonl(val, ds / "val.jsonl", a.format)}
    if test:
        hashes["test"] = write_jsonl(test, ds / "test.jsonl", a.format)

    manifest = {
        "tool_version": __version__,
        "head": head_sha(repo),
        "format": a.format,
        "synth_applied": applied,
        "args": {k: v for k, v in vars(a).items() if k not in ("func", "cmd")},
        "raw": len(raw),
        "rejected": dict(rejected),
        "splits": {n: {"count": len(s), "by_task": _dist(s)} for n, s in
                   (("train", train), ("val", val), ("test", test)) if s or n != "test"},
        "sha256": hashes,
    }
    (ds / "manifest.json").write_text(json.dumps(manifest, indent=2))
    _log(f"raw={len(raw)} kept={len(kept)} train={len(train)} val={len(val)} test={len(test)}")
    _log(f"rejected: {dict(rejected)}")
    _log(f"task mix (all splits): {_dist(kept)}")
    _log(f"Dataset -> {ds}")
    events.emit("done", stage="build", raw=len(raw), kept=len(kept), train=len(train),
                val=len(val), test=len(test), rejected=dict(rejected), path=str(ds))
    return 0


def sample(a) -> int:
    """Write a random sample of final examples to review.md for human spot-checks."""
    out = out_dir(a)
    path = out / "dataset" / "train.jsonl"
    if not path.exists():
        _log("No dataset. Run `repo2lora build` first.")
        return 1
    rows = [json.loads(line) for line in path.open(encoding="utf-8")]
    random.Random(a.seed).shuffle(rows)
    parts = []
    for i, r in enumerate(rows[: a.n], 1):
        msgs = r.get("messages") or [{"content": r["prompt"]}, {"content": r["completion"]}]
        parts.append(f"## {i}. {r['task_type']} ({r['id']})\n\n### Input\n\n{msgs[-2]['content']}\n\n"
                     f"### Output\n\n```\n{msgs[-1]['content']}\n```\n")
    (out / "review.md").write_text("\n".join(parts), encoding="utf-8")
    _log(f"Wrote {min(a.n, len(rows))} examples -> {out / 'review.md'}")
    events.emit("done", stage="sample", count=min(a.n, len(rows)), path=str(out / "review.md"))
    return 0


def synthesize(a) -> int:
    return synth_run(a)


def doctor(a) -> int:
    return doctor_run(a)
